package com.jeetatv.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.jeetatv.app.data.JeetaDatabase
import com.jeetatv.app.ui.JeetaTVApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = JeetaDatabase(applicationContext)
        setContent { JeetaTVApp(db) }
    }
}
