package com.jeetatv.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jeetatv.app.data.*
import kotlinx.coroutines.launch
import java.net.URLDecoder
import java.net.URLEncoder

@Composable
fun JeetaTVApp(db: JeetaDatabase) {
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var providers by remember { mutableStateOf<List<Provider>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            runCatching {
                val ps = db.providers().all().map { it.toModel() }
                providers = ps
                ps.flatMap { loadProvider(it) }
            }.onSuccess { channels = it }
                .onFailure { error = it.message ?: "Unable to load providers" }
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf(
                    "home" to "Home",
                    "live" to "Live",
                    "movies" to "Movies",
                    "series" to "Series",
                    "favorites" to "Favorites"
                ).forEach { (route, label) ->
                    NavigationBarItem(
                        selected = false,
                        onClick = { nav.navigate(route) },
                        icon = { Text(label.first().toString()) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(nav, channels, providers, ::refresh) }
            composable("live") { LiveScreen(nav, channels, db) }
            composable("movies") { CatalogScreen(nav, "Movies", channels.filter { it.kind == "movie" }, db) }
            composable("series") { CatalogScreen(nav, "Series", channels.filter { it.kind == "series" }, db) }
            composable("favorites") { FavoritesScreen(nav, channels, db) }
            composable("history") { HistoryScreen(nav, db) }
            composable("epg") { EpgScreen() }
            composable("providers") { ProviderScreen(db, providers, ::refresh) }
            composable("settings") { SettingsScreen(nav, db) }
            composable("add") { AddPlaylistScreen(db) { refresh(); nav.popBackStack() } }
            composable("player/{url}/{title}") { entry ->
                PlayerScreen(
                    URLDecoder.decode(entry.arguments?.getString("url").orEmpty(), "UTF-8"),
                    db,
                    URLDecoder.decode(entry.arguments?.getString("title").orEmpty(), "UTF-8")
                )
            }
        }
    }

    error?.let { message ->
        AlertDialog(
            onDismissRequest = { error = null },
            confirmButton = { TextButton(onClick = { error = null }) { Text("OK") } },
            title = { Text("Jeeta TV") },
            text = { Text(message) }
        )
    }
}

@Composable
fun HomeScreen(nav: NavHostController, ch: List<Channel>, ps: List<Provider>, refresh: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Jeeta TV", style = MaterialTheme.typography.headlineLarge)
        Text("Your personal IPTV hub", style = MaterialTheme.typography.bodyLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StatCard("Live", ch.count { it.kind == "live" }, Modifier.weight(1f))
            StatCard("Movies", ch.count { it.kind == "movie" }, Modifier.weight(1f))
            StatCard("Series", ch.count { it.kind == "series" }, Modifier.weight(1f))
        }
        Button(onClick = { nav.navigate("live") }, modifier = Modifier.fillMaxWidth()) { Text("▶  Live TV") }
        OutlinedButton(onClick = { nav.navigate("movies") }, modifier = Modifier.fillMaxWidth()) { Text("🎬  Movies") }
        OutlinedButton(onClick = { nav.navigate("series") }, modifier = Modifier.fillMaxWidth()) { Text("📺  Series") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { nav.navigate("history") }, modifier = Modifier.weight(1f)) { Text("History") }
            OutlinedButton(onClick = { nav.navigate("favorites") }, modifier = Modifier.weight(1f)) { Text("Favorites") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { nav.navigate("epg") }, modifier = Modifier.weight(1f)) { Text("EPG") }
            OutlinedButton(onClick = { nav.navigate("providers") }, modifier = Modifier.weight(1f)) { Text("Providers") }
        }
        OutlinedButton(onClick = refresh, modifier = Modifier.fillMaxWidth()) { Text("Refresh all providers (${ps.size})") }
        Text("Use only IPTV services and playlists you are authorized to access.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun StatCard(t: String, n: Int, m: Modifier) {
    Card(m) { Column(Modifier.padding(12.dp)) { Text(n.toString(), style = MaterialTheme.typography.headlineSmall); Text(t) } }
}

@Composable
fun LiveScreen(nav: NavHostController, ch: List<Channel>, db: JeetaDatabase) {
    var q by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("All") }
    val groups = listOf("All") + ch.filter { it.kind == "live" }.map { it.group }.distinct().sorted()
    val list = ch.filter { it.kind == "live" && (group == "All" || it.group == group) && it.name.contains(q, true) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Search live channels") })
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(groups) { g -> FilterChip(selected = g == group, onClick = { group = g }, label = { Text(g) }) }
        }
        LazyColumn { items(list, key = { it.id }) { c -> ChannelRow(c, db) { openPlayer(nav, c) } } }
    }
}

@Composable
fun CatalogScreen(nav: NavHostController, title: String, items: List<Channel>, db: JeetaDatabase) {
    var q by remember { mutableStateOf("") }
    val list = items.filter { it.name.contains(q, true) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Search $title") })
        LazyColumn { items(list, key = { it.id }) { c -> ChannelRow(c, db) { openPlayer(nav, c) } } }
    }
}

@Composable
fun ChannelRow(c: Channel, db: JeetaDatabase, onClick: () -> Unit) {
    var fav by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(c.id) { fav = db.favorites().exists(c.id) }

    ListItem(
        headlineContent = { Text(c.name) },
        supportingContent = { Text(c.group) },
        leadingContent = { Text(if (c.kind == "movie") "🎬" else if (c.kind == "series") "📺" else "▶") },
        trailingContent = {
            TextButton(onClick = {
                fav = !fav
                scope.launch {
                    if (fav) db.favorites().add(FavoriteEntity(c.id, c.kind))
                    else db.favorites().removeById(c.id)
                }
            }) { Text(if (fav) "★" else "☆") }
        },
        modifier = Modifier.clickable { onClick() }
    )
}

fun openPlayer(nav: NavHostController, c: Channel) {
    if (c.streamUrl.startsWith("xtream-series://")) return
    nav.navigate("player/${URLEncoder.encode(c.streamUrl, "UTF-8")}/${URLEncoder.encode(c.name, "UTF-8")}")
}

@Composable
fun FavoritesScreen(nav: NavHostController, ch: List<Channel>, db: JeetaDatabase) {
    var ids by remember { mutableStateOf(emptySet<String>()) }
    LaunchedEffect(Unit) { ids = db.favorites().all().map { it.contentId }.toSet() }
    val list = ch.filter { it.id in ids }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Favorites", style = MaterialTheme.typography.headlineMedium)
        LazyColumn { items(list, key = { it.id }) { c -> ChannelRow(c, db) { openPlayer(nav, c) } } }
    }
}

@Composable
fun HistoryScreen(nav: NavHostController, db: JeetaDatabase) {
    var history by remember { mutableStateOf<List<HistoryEntity>>(emptyList()) }
    LaunchedEffect(Unit) { history = db.history().recent() }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Continue Watching", style = MaterialTheme.typography.headlineMedium)
        LazyColumn {
            items(history, key = { it.contentId }) { item ->
                ListItem(
                    headlineContent = { Text(item.title.ifBlank { "Watched item" }) },
                    supportingContent = { Text(item.type) },
                    modifier = Modifier.clickable {
                        nav.navigate("player/${URLEncoder.encode(item.url, "UTF-8")}/${URLEncoder.encode(item.title, "UTF-8")}")
                    }
                )
            }
        }
    }
}

@Composable
fun EpgScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("EPG / TV Guide", style = MaterialTheme.typography.headlineMedium)
        Text("XMLTV guide support is available in the data layer. Add your XMLTV URL in the provider settings in the next provider-sync pass.")
        Text("Program matching uses tvg-id when supplied by your playlist.")
    }
}

@Composable
fun ProviderScreen(db: JeetaDatabase, ps: List<Provider>, refresh: () -> Unit) {
    var add by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    if (add) {
        AddPlaylistScreen(db) { add = false; refresh() }
    } else {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("Providers", style = MaterialTheme.typography.headlineMedium)
            Button(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("Add provider") }
            Spacer(Modifier.height(8.dp))
            LazyColumn {
                items(ps, key = { it.id }) { p ->
                    ListItem(
                        headlineContent = { Text(p.name) },
                        supportingContent = { Text(p.type.label + " • " + p.baseUrl) },
                        trailingContent = {
                            TextButton(onClick = { scope.launch { db.providers().delete(p.id); refresh() } }) { Text("Delete") }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(nav: NavHostController, db: JeetaDatabase) {
    var confirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Text("Player: Media3 / ExoPlayer", style = MaterialTheme.typography.bodyLarge)
        Text("Fullscreen, audio/subtitle tracks and adaptive streaming are handled by the player when the stream exposes them.")
        Text("Parental controls, profiles, casting and advanced Android TV controls are planned as the next hardening layer.")
        OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Clear watching history") }
        OutlinedButton(onClick = { nav.popBackStack() }, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Clear history?") },
            text = { Text("This removes local Continue Watching history.") },
            confirmButton = {
                TextButton(onClick = { scope.launch { db.history().clear(); confirm = false } }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}
