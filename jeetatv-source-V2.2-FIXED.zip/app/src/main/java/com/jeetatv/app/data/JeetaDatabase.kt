package com.jeetatv.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Lightweight local persistence using SharedPreferences.
 * This avoids annotation processing so the app can build reliably on cloud CI.
 */
class JeetaDatabase(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("jeetatv", Context.MODE_PRIVATE)
    fun providers() = ProviderStore(prefs)
    fun favorites() = FavoriteStore(prefs)
    fun history() = HistoryStore(prefs)
}

class ProviderStore(private val prefs: android.content.SharedPreferences) {
    suspend fun all(): List<ProviderEntity> {
        val a = JSONArray(prefs.getString("providers", "[]"))
        return buildList { for (i in 0 until a.length()) add(fromJson(a.getJSONObject(i))) }.sortedBy { it.name.lowercase() }
    }
    suspend fun insert(item: ProviderEntity): Long {
        val current = all().toMutableList()
        val id = if (item.id == 0L) (current.maxOfOrNull { it.id } ?: 0L) + 1 else item.id
        current.removeAll { it.id == id }
        current.add(item.copy(id = id))
        save(current)
        return id
    }
    suspend fun delete(id: Long) { save(all().filterNot { it.id == id }) }
    private fun save(items: List<ProviderEntity>) { prefs.edit().putString("providers", JSONArray().apply { items.forEach { put(toJson(it)) } }.toString()).apply() }
    private fun toJson(x: ProviderEntity) = JSONObject().apply { put("id",x.id);put("name",x.name);put("type",x.type);put("baseUrl",x.baseUrl);put("username",x.username);put("password",x.password);put("mac",x.macAddress);put("auto",x.autoRefresh) }
    private fun fromJson(o: JSONObject)=ProviderEntity(o.optLong("id"),o.optString("name"),o.optString("type"),o.optString("baseUrl"),o.optString("username").ifBlank{null},o.optString("password").ifBlank{null},o.optString("mac").ifBlank{null},o.optBoolean("auto",true))
}

class FavoriteStore(private val prefs: android.content.SharedPreferences) {
    suspend fun all(): List<FavoriteEntity> = JSONArray(prefs.getString("favorites", "[]")).let { a -> buildList { for(i in 0 until a.length()){val o=a.getJSONObject(i);add(FavoriteEntity(o.optString("id"),o.optString("type"))) } } }
    suspend fun add(item: FavoriteEntity) { val x=all().filterNot{it.contentId==item.contentId}.toMutableList();x.add(item);save(x) }
    suspend fun removeById(id:String){save(all().filterNot{it.contentId==id})}
    suspend fun exists(id:String)=all().any{it.contentId==id}
    private fun save(items:List<FavoriteEntity>){prefs.edit().putString("favorites",JSONArray().apply{items.forEach{put(JSONObject().apply{put("id",it.contentId);put("type",it.type)})}}.toString()).apply()}
}

class HistoryStore(private val prefs: android.content.SharedPreferences) {
    suspend fun recent(): List<HistoryEntity> = JSONArray(prefs.getString("history", "[]")).let { a -> buildList { for(i in 0 until a.length()){val o=a.getJSONObject(i);add(HistoryEntity(o.optString("id"),o.optString("url"),o.optString("title"),o.optString("type","live"),o.optLong("watchedAt"),o.optLong("position"),o.optLong("duration"))) } }.sortedByDescending{it.watchedAt}.take(100) }
    suspend fun upsert(item:HistoryEntity){save((allSync().filterNot{it.contentId==item.contentId}+item).sortedByDescending{it.watchedAt}.take(100))}
    suspend fun clear(){prefs.edit().remove("history").apply()}
    private fun allSync():List<HistoryEntity>{val a=JSONArray(prefs.getString("history","[]"));return buildList{for(i in 0 until a.length()){val o=a.getJSONObject(i);add(HistoryEntity(o.optString("id"),o.optString("url"),o.optString("title"),o.optString("type","live"),o.optLong("watchedAt"),o.optLong("position"),o.optLong("duration")))}}}
    private fun save(items:List<HistoryEntity>){prefs.edit().putString("history",JSONArray().apply{items.forEach{put(JSONObject().apply{put("id",it.contentId);put("url",it.url);put("title",it.title);put("type",it.type);put("watchedAt",it.watchedAt);put("position",it.positionMs);put("duration",it.durationMs)})}}.toString()).apply()}
}

data class ProviderEntity(@JvmField val id:Long=0,val name:String,val type:String,val baseUrl:String,val username:String?,val password:String?,val macAddress:String?,val autoRefresh:Boolean)
data class FavoriteEntity(val contentId:String,val type:String)
data class HistoryEntity(val contentId:String,val url:String,val title:String="",val type:String="live",val watchedAt:Long,val positionMs:Long=0,val durationMs:Long=0)

fun ProviderEntity.toModel()=Provider(id,name,ProviderType.valueOf(type),baseUrl,username,password,macAddress,autoRefresh)
fun Provider.toEntity()=ProviderEntity(id,name,type.name,baseUrl,username,password,macAddress,autoRefresh)
