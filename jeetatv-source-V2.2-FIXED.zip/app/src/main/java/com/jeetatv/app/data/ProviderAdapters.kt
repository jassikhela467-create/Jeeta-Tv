package com.jeetatv.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder

interface ProviderAdapter {
    suspend fun load(provider: Provider): List<Channel>
}

private val client = OkHttpClient.Builder().followRedirects(true).build()

private fun get(url: String): String = client
    .newCall(Request.Builder().url(url).header("User-Agent", "JeetaTV/2.0").build())
    .execute()
    .use { response ->
        require(response.isSuccessful) { "Request failed: ${response.code}" }
        response.body?.string().orEmpty()
    }

class M3UProviderAdapter : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        M3UParser.parse(get(provider.baseUrl), provider.id)
    }
}

class XtreamProviderAdapter : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        val base = provider.baseUrl.trimEnd('/')
        val username = provider.username ?: error("Xtream username is required")
        val password = provider.password ?: error("Xtream password is required")

        fun api(action: String): JSONArray {
            val url = "$base/player_api.php?username=${URLEncoder.encode(username, "UTF-8")}" +
                "&password=${URLEncoder.encode(password, "UTF-8")}&action=$action"
            return JSONArray(get(url))
        }

        val liveCategories = mutableMapOf<String, String>()
        val cats = api("get_live_categories")
        for (i in 0 until cats.length()) {
            val o = cats.optJSONObject(i) ?: continue
            liveCategories[o.optString("category_id")] = o.optString("category_name", "Live")
        }

        val out = mutableListOf<Channel>()
        val live = api("get_live_streams")
        for (i in 0 until live.length()) {
            val o = live.optJSONObject(i) ?: continue
            val id = o.optString("stream_id")
            if (id.isBlank()) continue
            out += Channel(
                "${provider.id}_live_$id",
                provider.id,
                o.optString("name", "Channel"),
                liveCategories[o.optString("category_id")] ?: "Live",
                o.optString("stream_icon").takeIf { it.isNotBlank() },
                "$base/live/$username/$password/$id.m3u8",
                kind = "live"
            )
        }

        val vodCategories = runCatching { api("get_vod_categories") }.getOrDefault(JSONArray())
        val vodMap = mutableMapOf<String, String>()
        for (i in 0 until vodCategories.length()) {
            val o = vodCategories.optJSONObject(i) ?: continue
            vodMap[o.optString("category_id")] = o.optString("category_name", "Movies")
        }

        val vod = runCatching { api("get_vod_streams") }.getOrDefault(JSONArray())
        for (i in 0 until vod.length()) {
            val o = vod.optJSONObject(i) ?: continue
            val id = o.optString("stream_id")
            if (id.isBlank()) continue
            val extension = o.optString("container_extension", "mp4")
            out += Channel(
                "${provider.id}_movie_$id",
                provider.id,
                o.optString("name", "Movie"),
                vodMap[o.optString("category_id")] ?: "Movies",
                o.optString("stream_icon").takeIf { it.isNotBlank() },
                "$base/movie/$username/$password/$id.$extension",
                kind = "movie",
                year = o.optString("year").takeIf { it.isNotBlank() },
                plot = o.optString("plot").takeIf { it.isNotBlank() },
                duration = o.optString("duration").takeIf { it.isNotBlank() }
            )
        }

        val seriesCategories = runCatching { api("get_series_categories") }.getOrDefault(JSONArray())
        val seriesMap = mutableMapOf<String, String>()
        for (i in 0 until seriesCategories.length()) {
            val o = seriesCategories.optJSONObject(i) ?: continue
            seriesMap[o.optString("category_id")] = o.optString("category_name", "Series")
        }

        val series = runCatching { api("get_series") }.getOrDefault(JSONArray())
        for (i in 0 until series.length()) {
            val o = series.optJSONObject(i) ?: continue
            val id = o.optString("series_id")
            if (id.isBlank()) continue
            out += Channel(
                "${provider.id}_series_$id",
                provider.id,
                o.optString("name", "Series"),
                seriesMap[o.optString("category_id")] ?: "Series",
                o.optString("cover").takeIf { it.isNotBlank() },
                "xtream-series://${provider.id}/$id",
                kind = "series",
                plot = o.optString("plot").takeIf { it.isNotBlank() }
            )
        }

        out
    }
}

class PortalProviderAdapter : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        error("Portal/MAC services vary by provider; this adapter requires provider-specific portal compatibility")
    }
}

suspend fun loadProvider(provider: Provider): List<Channel> {
    return when (provider.type) {
        ProviderType.M3U -> M3UProviderAdapter().load(provider)
        ProviderType.XTREAM -> XtreamProviderAdapter().load(provider)
        ProviderType.PORTAL -> PortalProviderAdapter().load(provider)
    }
}
