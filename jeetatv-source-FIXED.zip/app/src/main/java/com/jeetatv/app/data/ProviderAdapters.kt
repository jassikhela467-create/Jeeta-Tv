package com.jeetatv.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Headers
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.security.MessageDigest

interface ProviderAdapter {
    suspend fun load(provider: Provider): List<Channel>
}

class M3UProviderAdapter(
    private val http: OkHttpClient = OkHttpClient.Builder().followRedirects(true).build()
) : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(provider.baseUrl)
            .header("User-Agent", "JeetaTV/1.0")
            .build()
        http.newCall(request).execute().use { response ->
            require(response.isSuccessful) { "Playlist request failed: ${response.code}" }
            M3UParser.parse(response.body?.string().orEmpty(), provider.id)
        }
    }
}

class XtreamProviderAdapter(
    private val http: OkHttpClient = OkHttpClient.Builder().followRedirects(true).build()
) : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        val base = provider.baseUrl.trimEnd('/')
        val username = provider.username ?: error("Xtream username is required")
        val password = provider.password ?: error("Xtream password is required")

        fun api(action: String): JSONArray {
            val url = buildString {
                append(base)
                append("/player_api.php?username=")
                append(URLEncoder.encode(username, "UTF-8"))
                append("&password=")
                append(URLEncoder.encode(password, "UTF-8"))
                append("&action=")
                append(action)
            }
            http.newCall(
                Request.Builder().url(url).header("User-Agent", "JeetaTV/1.0").build()
            ).execute().use { response ->
                require(response.isSuccessful) { "Xtream request failed: ${response.code}" }
                val body = response.body?.string().orEmpty()
                return JSONArray(body)
            }
        }

        val categories = api("get_live_categories")
        val categoryNames = mutableMapOf<String, String>()
        for (i in 0 until categories.length()) {
            val item = categories.optJSONObject(i) ?: continue
            categoryNames[item.optString("category_id")] = item.optString("category_name", "Other")
        }

        val streams = api("get_live_streams")
        buildList {
            for (i in 0 until streams.length()) {
                val item = streams.optJSONObject(i) ?: continue
                val streamId = item.optString("stream_id")
                if (streamId.isBlank()) continue
                add(
                    Channel(
                        id = "${provider.id}_live_$streamId",
                        providerId = provider.id,
                        name = item.optString("name", "Channel"),
                        group = categoryNames[item.optString("category_id")] ?: "Live",
                        logo = item.optString("stream_icon").takeIf { it.isNotBlank() },
                        streamUrl = "$base/live/$username/$password/$streamId.m3u8",
                        kind = "live"
                    )
                )
            }
        }
    }
}

class PortalProviderAdapter(
    private val http: OkHttpClient = OkHttpClient.Builder().followRedirects(true).build()
) : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        val mac = provider.macAddress?.trim().orEmpty()
        require(mac.isNotBlank()) { "MAC address is required" }
        val base = provider.baseUrl.trimEnd('/')
        val deviceId = md5(mac)
        val headers = Headers.Builder()
            .add("User-Agent", "Mozilla/5.0")
            .add("X-User-Agent", "Model: MAG254; Link: WiFi")
            .add("Cookie", "mac=$mac; stb_lang=en; timezone=GMT")
            .build()

        fun request(url: String, extraHeaders: Headers = headers): JSONObject {
            http.newCall(Request.Builder().url(url).headers(extraHeaders).build()).execute().use { response ->
                require(response.isSuccessful) { "Portal request failed: ${response.code}" }
                return JSONObject(response.body?.string().orEmpty())
            }
        }

        val handshake = request(
            "$base/portal.php?type=stb&action=handshake&token=&prehash=0&JsHttpRequest=1-xml"
        )
        val token = handshake.optJSONObject("js")?.optString("token").orEmpty()
        require(token.isNotBlank()) { "Portal handshake failed" }

        val authHeaders = headers.newBuilder()
            .add("Authorization", "Bearer $token")
            .build()

        request(
            "$base/portal.php?type=stb&action=get_profile&hd=1&device_id=$deviceId&device_id2=$deviceId&sn=$deviceId&JsHttpRequest=1-xml",
            authHeaders
        )

        val list = request(
            "$base/portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml",
            authHeaders
        )
        val array = list.optJSONObject("js")?.optJSONArray("data") ?: JSONArray()

        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val name = item.optString("name")
                val cmd = item.optString("cmd")
                if (id.isBlank() || name.isBlank() || cmd.isBlank()) continue
                add(
                    Channel(
                        id = "${provider.id}_portal_$id",
                        providerId = provider.id,
                        name = name,
                        group = "Portal",
                        logo = item.optString("logo").takeIf { it.isNotBlank() },
                        streamUrl = cmd,
                        kind = "live"
                    )
                )
            }
        }
    }

    private fun md5(value: String): String = MessageDigest
        .getInstance("MD5")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }
}

suspend fun loadProvider(provider: Provider): List<Channel> = when (provider.type) {
    ProviderType.M3U -> M3UProviderAdapter().load(provider)
    ProviderType.XTREAM -> XtreamProviderAdapter().load(provider)
    ProviderType.PORTAL -> PortalProviderAdapter().load(provider)
}
