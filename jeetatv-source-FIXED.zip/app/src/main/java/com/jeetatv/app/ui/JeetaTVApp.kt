package com.jeetatv.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jeetatv.app.data.Channel
import com.jeetatv.app.data.JeetaDatabase
import com.jeetatv.app.data.loadProvider
import com.jeetatv.app.data.toModel
import kotlinx.coroutines.launch
import java.net.URLDecoder
import java.net.URLEncoder

@Composable
fun JeetaTVApp(db: JeetaDatabase) {
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            val result = runCatching {
                db.providers().all().flatMap { loadProvider(it.toModel()) }
            }
            result.onSuccess { channels = it }
                .onFailure { error = it.message ?: "Could not load providers" }
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        bottomBar = {
            NavigationBar {
                val destinations = listOf(
                    "home" to "Home",
                    "live" to "Live",
                    "movies" to "Movies",
                    "series" to "Series",
                    "favorites" to "Favorites"
                )
                destinations.forEach { (route, label) ->
                    NavigationBarItem(
                        selected = false,
                        onClick = { nav.navigate(route) },
                        icon = { Text(label.take(1)) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") { HomeScreen(nav, channels.size, ::refresh) }
            composable("live") { LiveScreen(nav, channels, db) }
            composable("movies") { CatalogScreen("Movies", channels.filter { it.kind == "movie" }) }
            composable("series") { CatalogScreen("Series", channels.filter { it.kind == "series" }) }
            composable("favorites") { FavoritesScreen(nav, channels, db) }
            composable("add") {
                AddPlaylistScreen(db) {
                    refresh()
                    nav.popBackStack()
                }
            }
            composable("player/{url}") { backStackEntry ->
                val encoded = backStackEntry.arguments?.getString("url").orEmpty()
                PlayerScreen(URLDecoder.decode(encoded, "UTF-8"), db)
            }
        }
    }

    error?.let { message ->
        AlertDialog(
            onDismissRequest = { error = null },
            confirmButton = { TextButton(onClick = { error = null }) { Text("OK") } },
            title = { Text("Jeeta TV") },
            text = { Text(message) }
        )
    }
}

@Composable
fun HomeScreen(nav: NavHostController, count: Int, onRefresh: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Jeeta TV", style = MaterialTheme.typography.headlineLarge)
        Text("Your IPTV player")
        Button(onClick = { nav.navigate("add") }, modifier = Modifier.fillMaxWidth()) {
            Text("Add playlist / provider")
        }
        OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) {
            Text("Refresh channels")
        }
        Text("$count channels loaded")
        Text(
            "Supports M3U/M3U8, Xtream Codes and compatible Portal/MAC services. Use only services you are authorized to access.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun LiveScreen(nav: NavHostController, channels: List<Channel>, db: JeetaDatabase) {
    var query by remember { mutableStateOf("") }
    val live = channels.filter { it.kind == "live" && it.name.contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Search channels") }
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(live, key = { it.id }) { channel ->
                ChannelRow(channel) {
                    scopeNavigateToPlayer(nav, channel.streamUrl)
                }
            }
        }
    }
}

private fun scopeNavigateToPlayer(nav: NavHostController, url: String) {
    nav.navigate("player/${URLEncoder.encode(url, "UTF-8")}")
}

@Composable
fun CatalogScreen(title: String, items: List<Channel>) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Text(if (items.isEmpty()) "No content loaded yet." else "${items.size} items available.")
    }
}

@Composable
fun FavoritesScreen(nav: NavHostController, channels: List<Channel>, db: JeetaDatabase) {
    var ids by remember { mutableStateOf(emptySet<String>()) }
    LaunchedEffect(Unit) {
        ids = db.favorites().all().map { it.contentId }.toSet()
    }
    val list = channels.filter { it.id in ids }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Favorites", style = MaterialTheme.typography.headlineMedium)
        LazyColumn {
            items(list, key = { it.id }) { channel ->
                ChannelRow(channel) { scopeNavigateToPlayer(nav, channel.streamUrl) }
            }
        }
    }
}

@Composable
fun ChannelRow(channel: Channel, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(channel.name) },
        supportingContent = { Text(channel.group) },
        leadingContent = { Text("▶") },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
