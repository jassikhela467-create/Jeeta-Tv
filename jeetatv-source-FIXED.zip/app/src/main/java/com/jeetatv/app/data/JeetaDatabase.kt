package com.jeetatv.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "providers")
data class ProviderEntity(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val baseUrl: String,
    val username: String?,
    val password: String?,
    val macAddress: String?,
    val autoRefresh: Boolean
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @androidx.room.PrimaryKey val contentId: String,
    val type: String
)

@Entity(tableName = "history")
data class HistoryEntity(
    @androidx.room.PrimaryKey val contentId: String,
    val url: String,
    val watchedAt: Long,
    val positionMs: Long = 0
)

@Dao
interface ProviderDao {
    @Query("SELECT * FROM providers ORDER BY name")
    suspend fun all(): List<ProviderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ProviderEntity): Long

    @Query("DELETE FROM providers WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites")
    suspend fun all(): List<FavoriteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(item: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE contentId = :id")
    suspend fun removeById(id: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE contentId = :id)")
    suspend fun exists(id: String): Boolean
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY watchedAt DESC LIMIT 100")
    suspend fun recent(): List<HistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: HistoryEntity)
}

@Database(
    entities = [ProviderEntity::class, FavoriteEntity::class, HistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class JeetaDatabase : RoomDatabase() {
    abstract fun providers(): ProviderDao
    abstract fun favorites(): FavoriteDao
    abstract fun history(): HistoryDao
}

fun ProviderEntity.toModel() = Provider(
    id = id,
    name = name,
    type = ProviderType.valueOf(type),
    baseUrl = baseUrl,
    username = username,
    password = password,
    macAddress = macAddress,
    autoRefresh = autoRefresh
)

fun Provider.toEntity() = ProviderEntity(
    id = id,
    name = name,
    type = type.name,
    baseUrl = baseUrl,
    username = username,
    password = password,
    macAddress = macAddress,
    autoRefresh = autoRefresh
)
