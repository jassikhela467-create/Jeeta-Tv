package com.jeetatv.app.ui

import android.net.Uri
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.jeetatv.app.data.HistoryEntity
import com.jeetatv.app.data.JeetaDatabase
import kotlinx.coroutines.launch

@Composable
fun PlayerScreen(url: String, db: JeetaDatabase) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        onDispose {
            val position = player.currentPosition
            scope.launch {
                db.history().upsert(
                    HistoryEntity(
                        contentId = url,
                        url = url,
                        watchedAt = System.currentTimeMillis(),
                        positionMs = position
                    )
                )
            }
            player.release()
        }
    }

    AndroidView(
        factory = { PlayerView(it).apply { this.player = player; useController = true } },
        modifier = Modifier.fillMaxSize()
    )
}
