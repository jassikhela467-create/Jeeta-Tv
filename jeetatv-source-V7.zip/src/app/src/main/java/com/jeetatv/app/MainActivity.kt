package com.jeetatv.app

import android.os.Bundle
import android.content.pm.PackageManager
import androidx.core.view.WindowCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.jeetatv.app.data.JeetaDatabase
import com.jeetatv.app.ui.JeetaTVApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val db = JeetaDatabase(applicationContext)
        setContent { JeetaTVApp(db) }
    }
}
