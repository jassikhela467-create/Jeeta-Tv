package com.jeetatv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.jeetatv.app.data.*
import kotlinx.coroutines.launch
import java.net.URLDecoder
import java.net.URLEncoder

private val Ink = Color(0xFF090D1A)
private val Panel = Color(0xFF151B2D)
private val Violet = Color(0xFF8B5CF6)
private val Mint = Color(0xFF38D9A9)
private val SoftText = Color(0xFFADB7D0)

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun JeetaTVApp(db: JeetaDatabase) {
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var providers by remember { mutableStateOf<List<Provider>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: "home"
    val mainRoutes = setOf("home", "live", "movies", "series", "favorites")

    fun refresh() {
        scope.launch {
            runCatching {
                val ps = db.providers().all().map { it.toModel() }
                providers = ps
                ps.flatMap { loadProvider(it) }
            }.onSuccess { channels = it }
                .onFailure { error = it.message ?: "Unable to load providers" }
        }
    }
    LaunchedEffect(Unit) { refresh() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, secondary = Mint, background = Ink, surface = Panel,
            onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                if (route in mainRoutes) {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                Box(Modifier.size(34.dp).background(Brush.linearGradient(listOf(Violet, Mint)), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                                    Text("J", fontWeight = FontWeight.Black, color = Color.White)
                                }
                                Column {
                                    Text("JEETA TV", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                                    Text("YOUR ENTERTAINMENT HUB", style = MaterialTheme.typography.labelSmall, color = SoftText)
                                }
                            }
                        },
                        actions = {
                            TextButton(onClick = { nav.navigate("providers") }) { Text("＋", color = Mint, style = MaterialTheme.typography.titleLarge) }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                    )
                }
            },
            bottomBar = {
                if (route in mainRoutes) {
                    NavigationBar(containerColor = Panel, contentColor = Color.White) {
                        val tabs = listOf(
                            Triple("home", "Home", "⌂"), Triple("live", "Live TV", "▶"),
                            Triple("movies", "Movies", "▣"), Triple("series", "Series", "▤"),
                            Triple("favorites", "Saved", "★")
                        )
                        tabs.forEach { (destination, label, glyph) ->
                            NavigationBarItem(
                                selected = route == destination,
                                onClick = {
                                    if (route != destination) nav.navigate(destination) {
                                        popUpTo("home") { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Text(glyph, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Mint, selectedTextColor = Mint,
                                    indicatorColor = Violet.copy(alpha = 0.22f), unselectedIconColor = SoftText,
                                    unselectedTextColor = SoftText
                                )
                            )
                        }
                    }
                }
            }
        ) { pad ->
            NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                composable("home") { HomeScreen(nav, channels, providers, ::refresh) }
                composable("live") { LiveScreen(nav, channels, db) }
                composable("movies") { CatalogScreen(nav, "Movies", channels.filter { it.kind == "movie" }, db) }
                composable("series") { CatalogScreen(nav, "Series", channels.filter { it.kind == "series" }, db) }
                composable("favorites") { FavoritesScreen(nav, channels, db) }
                composable("history") { HistoryScreen(nav, db) }
                composable("epg") { EpgScreen() }
                composable("providers") { ProviderScreen(db, providers, ::refresh) }
                composable("settings") { SettingsScreen(nav, db) }
                composable("add") { AddPlaylistScreen(db) { refresh(); nav.popBackStack() } }
                composable("player/{url}/{title}") { entry ->
                    PlayerScreen(
                        URLDecoder.decode(entry.arguments?.getString("url").orEmpty(), "UTF-8"), db,
                        URLDecoder.decode(entry.arguments?.getString("title").orEmpty(), "UTF-8")
                    )
                }
            }
        }
        error?.let { message ->
            AlertDialog(onDismissRequest = { error = null }, confirmButton = { TextButton(onClick = { error = null }) { Text("OK") } }, title = { Text("Jeeta TV") }, text = { Text(message) })
        }
    }
}


@Composable
fun HomeScreen(nav: NavHostController, ch: List<Channel>, ps: List<Provider>, refresh: () -> Unit) {
    val liveCount = ch.count { it.kind == "live" }
    val movieCount = ch.count { it.kind == "movie" }
    val seriesCount = ch.count { it.kind == "series" }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Ink),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Box(Modifier.fillMaxWidth().height(184.dp).background(Brush.linearGradient(listOf(Color(0xFF37206D), Color(0xFF172B46), Color(0xFF123D42))), RoundedCornerShape(24.dp)).padding(20.dp)) {
                Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.8f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("YOUR SCREEN. YOUR WORLD.", color = Mint, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text("Entertainment,\nall in one place.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Color.White, lineHeight = MaterialTheme.typography.headlineMedium.lineHeight)
                    Button(onClick = { nav.navigate("live") }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 7.dp)) { Text("▶  Watch Live", fontWeight = FontWeight.Bold) }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("LIVE CHANNELS", liveCount.toString(), "●", Mint, Modifier.weight(1f))
                MetricCard("MOVIES", movieCount.toString(), "▣", Violet, Modifier.weight(1f))
                MetricCard("SERIES", seriesCount.toString(), "▤", Color(0xFFFFB454), Modifier.weight(1f))
            }
        }
        item { SectionHeading("Explore", "Find something to watch") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item { ExploreCard("▶", "Live TV", "News, sports & more", Mint) { nav.navigate("live") } }
                item { ExploreCard("▣", "Movies", "Your movie library", Violet) { nav.navigate("movies") } }
                item { ExploreCard("▤", "Series", "Episodes & seasons", Color(0xFFFFB454)) { nav.navigate("series") } }
            }
        }
        item { SectionHeading("Quick access", "Your personal library") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickRow("★", "Favorites", "Your saved channels and titles") { nav.navigate("favorites") }
                QuickRow("◷", "Continue watching", "Pick up where you left off") { nav.navigate("history") }
                QuickRow("▦", "TV Guide", "Program guide and schedule") { nav.navigate("epg") }
                QuickRow("⚙", "Providers & settings", "${ps.size} provider(s) connected") { nav.navigate("providers") }
            }
        }
        item {
            OutlinedButton(onClick = refresh, modifier = Modifier.fillMaxWidth()) { Text("↻  Refresh library") }
            Text("Use only IPTV services and playlists you are authorized to access.", color = SoftText, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp))
        }
        if (ch.isEmpty()) item { EmptyState("Your library is ready", "Add an authorized M3U playlist or provider to get started.") { nav.navigate("providers") } }
    }
}

@Composable
private fun MetricCard(label: String, value: String, glyph: String, accent: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(glyph, color = accent, style = MaterialTheme.typography.titleLarge)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, color = SoftText, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun SectionHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = SoftText)
    }
}

@Composable
private fun ExploreCard(glyph: String, title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Card(Modifier.width(176.dp).height(122.dp).clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(glyph, color = accent, style = MaterialTheme.typography.headlineSmall)
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = SoftText, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun QuickRow(glyph: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(42.dp).background(Violet.copy(alpha = 0.18f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text(glyph, color = Mint, style = MaterialTheme.typography.titleLarge) }
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = SoftText, style = MaterialTheme.typography.bodySmall) }
            Text("›", color = SoftText, style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String, onAdd: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("＋", color = Mint, style = MaterialTheme.typography.displaySmall)
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(body, color = SoftText, style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onAdd) { Text("Add provider") }
        }
    }
}

@Composable
fun LiveScreen(nav: NavHostController, ch: List<Channel>, db: JeetaDatabase) {
    var q by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("All") }
    val groups = listOf("All") + ch.filter { it.kind == "live" }.map { it.group }.distinct().sorted()
    val list = ch.filter { it.kind == "live" && (group == "All" || it.group == group) && it.name.contains(q, true) }
    Column(Modifier.fillMaxSize().background(Ink).padding(12.dp)) {
        Text("Live TV", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Search live channels") }, singleLine = true)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(vertical = 8.dp)) { items(groups) { g -> FilterChip(selected = g == group, onClick = { group = g }, label = { Text(g) }) } }
        if (list.isEmpty()) EmptyState("No channels found", "Add a provider or try another search.") { nav.navigate("providers") }
        else LazyColumn { items(list, key = { it.id }) { c -> ChannelRow(c, db) { openPlayer(nav, c) } } }
    }
}

@Composable
fun CatalogScreen(nav: NavHostController, title: String, items: List<Channel>, db: JeetaDatabase) {
    var q by remember { mutableStateOf("") }
    val list = items.filter { it.name.contains(q, true) }
    Column(Modifier.fillMaxSize().background(Ink).padding(12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Search $title") }, singleLine = true)
        if (list.isEmpty()) EmptyState("Nothing here yet", "Add a provider or search for another title.") { nav.navigate("providers") }
        else LazyColumn { items(list, key = { it.id }) { c -> ChannelRow(c, db) { openPlayer(nav, c) } } }
    }
}

@Composable
fun ChannelRow(c: Channel, db: JeetaDatabase, onClick: () -> Unit) {
    var fav by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(c.id) { fav = db.favorites().exists(c.id) }
    ListItem(
        headlineContent = { Text(c.name, fontWeight = FontWeight.SemiBold) },
        supportingContent = { Text(c.group, color = SoftText) },
        leadingContent = { Box(Modifier.size(44.dp).background(Panel, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text(if (c.kind == "movie") "▣" else if (c.kind == "series") "▤" else "▶", color = Mint) } },
        trailingContent = { TextButton(onClick = { fav = !fav; scope.launch { if (fav) db.favorites().add(FavoriteEntity(c.id, c.kind)) else db.favorites().removeById(c.id) } }) { Text(if (fav) "★" else "☆", color = if (fav) Mint else SoftText) } },
        modifier = Modifier.clickable { onClick() }, colors = ListItemDefaults.colors(containerColor = Ink)
    )
    HorizontalDivider(color = Panel)
}

fun openPlayer(nav: NavHostController, c: Channel) {
    if (c.streamUrl.startsWith("xtream-series://")) return
    nav.navigate("player/${URLEncoder.encode(c.streamUrl, "UTF-8")}/${URLEncoder.encode(c.name, "UTF-8")}")
}

@Composable
fun FavoritesScreen(nav: NavHostController, ch: List<Channel>, db: JeetaDatabase) {
    var ids by remember { mutableStateOf(emptySet<String>()) }
    LaunchedEffect(Unit) { ids = db.favorites().all().map { it.contentId }.toSet() }
    val list = ch.filter { it.id in ids }
    Column(Modifier.fillMaxSize().background(Ink).padding(12.dp)) {
        Text("Favorites", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        if (list.isEmpty()) Text("Saved channels and titles will appear here.", color = SoftText, modifier = Modifier.padding(top = 12.dp))
        LazyColumn { items(list, key = { it.id }) { c -> ChannelRow(c, db) { openPlayer(nav, c) } } }
    }
}

@Composable
fun HistoryScreen(nav: NavHostController, db: JeetaDatabase) {
    var history by remember { mutableStateOf<List<HistoryEntity>>(emptyList()) }
    LaunchedEffect(Unit) { history = db.history().recent() }
    Column(Modifier.fillMaxSize().background(Ink).padding(12.dp)) {
        Text("Continue Watching", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        LazyColumn { items(history, key = { it.contentId }) { item ->
            ListItem(headlineContent = { Text(item.title.ifBlank { "Watched item" }) }, supportingContent = { Text(item.type, color = SoftText) }, modifier = Modifier.clickable { nav.navigate("player/${URLEncoder.encode(item.url, "UTF-8")}/${URLEncoder.encode(item.title, "UTF-8")}") }, colors = ListItemDefaults.colors(containerColor = Ink))
        } }
    }
}

@Composable
fun EpgScreen() {
    Column(Modifier.fillMaxSize().background(Ink).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("TV Guide", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("EPG support is available in the data layer. Add an XMLTV URL in a future provider-sync update to display schedules.", color = SoftText)
        Text("Program matching uses tvg-id when supplied by your playlist.", color = SoftText)
    }
}

@Composable
fun ProviderScreen(db: JeetaDatabase, ps: List<Provider>, refresh: () -> Unit) {
    var add by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    if (add) AddPlaylistScreen(db) { add = false; refresh() }
    else Column(Modifier.fillMaxSize().background(Ink).padding(16.dp)) {
        Text("Providers", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Manage your authorized playlists and services.", color = SoftText, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        Button(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) { Text("＋  Add provider") }
        LazyColumn { items(ps, key = { it.id }) { p ->
            ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text(p.type.label + " • " + p.baseUrl, color = SoftText) }, trailingContent = { TextButton(onClick = { scope.launch { db.providers().delete(p.id); refresh() } }) { Text("Delete") } }, colors = ListItemDefaults.colors(containerColor = Ink))
            HorizontalDivider(color = Panel)
        } }
    }
}

@Composable
fun SettingsScreen(nav: NavHostController, db: JeetaDatabase) {
    var confirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(Ink).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("Playback", fontWeight = FontWeight.Bold); Text("Media3 / ExoPlayer", color = Mint); Text("Fullscreen, audio/subtitle tracks and adaptive streaming depend on what the stream provides.", color = SoftText) } }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("About Jeeta TV", fontWeight = FontWeight.Bold); Text("Version 3.0 • Personal IPTV player", color = SoftText); Text("Use only content and services you are authorized to access.", color = SoftText) } }
        OutlinedButton(onClick = { nav.navigate("history") }, modifier = Modifier.fillMaxWidth()) { Text("Continue watching") }
        OutlinedButton(onClick = { nav.navigate("epg") }, modifier = Modifier.fillMaxWidth()) { Text("TV Guide") }
        OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Clear watching history") }
        OutlinedButton(onClick = { nav.popBackStack() }, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("Clear history?") }, text = { Text("This removes local Continue Watching history.") }, confirmButton = { TextButton(onClick = { scope.launch { db.history().clear(); confirm = false } }) { Text("Clear") } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } })
}
