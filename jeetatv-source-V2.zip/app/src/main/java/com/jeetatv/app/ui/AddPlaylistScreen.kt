package com.jeetatv.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.jeetatv.app.data.JeetaDatabase
import com.jeetatv.app.data.Provider
import com.jeetatv.app.data.ProviderType
import com.jeetatv.app.data.toEntity
import kotlinx.coroutines.launch

@Composable
fun AddPlaylistScreen(db: JeetaDatabase, onSaved: () -> Unit) {
    var type by remember { mutableStateOf(ProviderType.M3U) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier.padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Add Provider", style = MaterialTheme.typography.headlineMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ProviderType.values().forEach { providerType ->
                FilterChip(
                    selected = type == providerType,
                    onClick = { type = providerType },
                    label = { Text(providerType.label) }
                )
            }
        }
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text(if (type == ProviderType.M3U) "M3U/M3U8 URL" else "Server / Portal URL") },
            modifier = Modifier.fillMaxWidth()
        )
        if (type == ProviderType.XTREAM) {
            OutlinedTextField(
                value = user,
                onValueChange = { user = it },
                label = { Text("Username") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = pass,
                onValueChange = { pass = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (type == ProviderType.PORTAL) {
            OutlinedTextField(
                value = mac,
                onValueChange = { mac = it },
                label = { Text("MAC address") },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Portal implementations vary. Use only an authorized service.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(4.dp))
        Button(
            enabled = !busy,
            onClick = {
                scope.launch {
                    busy = true
                    error = runCatching {
                        require(name.isNotBlank()) { "Name is required" }
                        require(url.isNotBlank()) { "URL is required" }
                        if (type == ProviderType.XTREAM) {
                            require(user.isNotBlank() && pass.isNotBlank()) {
                                "Username and password are required"
                            }
                        }
                        if (type == ProviderType.PORTAL) {
                            require(mac.isNotBlank()) { "MAC address is required" }
                        }
                        db.providers().insert(
                            Provider(
                                name = name.trim(),
                                type = type,
                                baseUrl = url.trim(),
                                username = user.trim().ifBlank { null },
                                password = pass.ifBlank { null },
                                macAddress = mac.trim().ifBlank { null }
                            ).toEntity()
                        )
                    }.exceptionOrNull()?.message
                    busy = false
                    if (error == null) onSaved()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (busy) "Saving…" else "Save Provider")
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
