package com.jeetatv.app.data

import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale

data class EpgChannel(val id:String,val name:String)
object XmltvParser {
    fun parse(xml:String):Pair<List<EpgChannel>,List<EpgProgram>> {
        val channels=mutableListOf<EpgChannel>(); val programs=mutableListOf<EpgProgram>();
        val p=Xml.newPullParser(); p.setInput(StringReader(xml)); var event=p.eventType; var currentId=""; var currentName=""; var inChannel=false; var inProgramme=false; var title=""; var desc=""; var start=0L; var end=0L; var channelId=""
        fun time(v:String):Long=runCatching{ SimpleDateFormat("yyyyMMddHHmmss Z",Locale.US).parse(v.trim())?.time?:0L }.getOrDefault(0L)
        while(event!=XmlPullParser.END_DOCUMENT){ when(event){ XmlPullParser.START_TAG->when(p.name){"channel"->{inChannel=true;currentId=p.getAttributeValue(null,"id").orEmpty()};"display-name"->if(inChannel&&!inProgramme)currentName=p.nextText();"programme"->{inProgramme=true;channelId=p.getAttributeValue(null,"channel").orEmpty();start=time(p.getAttributeValue(null,"start").orEmpty());end=time(p.getAttributeValue(null,"stop").orEmpty());title="";desc=""};"title"->if(inProgramme)title=p.nextText();"desc"->if(inProgramme)desc=p.nextText()}; XmlPullParser.END_TAG->when(p.name){"channel"->{if(currentId.isNotBlank())channels+=EpgChannel(currentId,currentName);inChannel=false};"programme"->{if(channelId.isNotBlank()&&title.isNotBlank())programs+=EpgProgram(channelId,title,desc,start,end);inProgramme=false}}}; event=p.next() }
        return channels to programs
    }
}
