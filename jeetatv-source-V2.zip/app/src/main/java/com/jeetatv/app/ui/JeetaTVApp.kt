package com.jeetatv.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.jeetatv.app.data.*
import kotlinx.coroutines.launch
import java.net.URLDecoder
import java.net.URLEncoder

@Composable
fun JeetaTVApp(db:JeetaDatabase){
 val nav=rememberNavController(); val scope=rememberCoroutineScope(); var channels by remember{mutableStateOf<List<Channel>>(emptyList())}; var providers by remember{mutableStateOf<List<Provider>>(emptyList())}; var error by remember{mutableStateOf<String?>(null)}
 fun refresh(){scope.launch{runCatching{val ps=db.providers().all().map{it.toModel()};providers=ps;ps.flatMap{loadProvider(it)}}.onSuccess{channels=it}.onFailure{error=it.message?:"Unable to load providers"}}}
 LaunchedEffect(Unit){refresh()}
 Scaffold(bottomBar={NavigationBar{listOf("home" to "Home","live" to "Live","movies" to "Movies","series" to "Series","favorites" to "Favorites").forEach{(r,l)->NavigationBarItem(selected=false,onClick={nav.navigate(r)},icon={Text(l.first().toString())},label={Text(l)})}}}){pad->
  NavHost(nav,"home",Modifier.padding(pad)){
   composable("home"){HomeScreen(nav,channels,providers,::refresh)}
   composable("live"){LiveScreen(nav,channels,db)}
   composable("movies"){CatalogScreen(nav,"Movies",channels.filter{it.kind=="movie"},db)}
   composable("series"){CatalogScreen(nav,"Series",channels.filter{it.kind=="series"},db)}
   composable("favorites"){FavoritesScreen(nav,channels,db)}
   composable("history"){HistoryScreen(nav,db)}
   composable("epg"){EpgScreen()}
   composable("providers"){ProviderScreen(db,providers,::refresh)}
   composable("settings"){SettingsScreen(nav,db)}
   composable("add"){AddPlaylistScreen(db){refresh();nav.popBackStack()}}
   composable("player/{url}/{title}"){b->PlayerScreen(URLDecoder.decode(b.arguments?.getString("url").orEmpty(),"UTF-8"),db,URLDecoder.decode(b.arguments?.getString("title").orEmpty(),"UTF-8"))}
  }
 }
 error?.let{AlertDialog(onDismissRequest={error=null},confirmButton={TextButton({error=null}){Text("OK")}},title={Text("Jeeta TV")},text={Text(it)})}
}

@Composable fun HomeScreen(nav:NavHostController,ch:List<Channel>,ps:List<Provider>,refresh:()->Unit){
 Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Text("Jeeta TV",style=MaterialTheme.typography.headlineLarge); Text("Your personal IPTV hub",style=MaterialTheme.typography.bodyLarge)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){StatCard("Live",ch.count{it.kind=="live"},Modifier.weight(1f));StatCard("Movies",ch.count{it.kind=="movie"},Modifier.weight(1f));StatCard("Series",ch.count{it.kind=="series"},Modifier.weight(1f))}
  Button({nav.navigate("live")},Modifier.fillMaxWidth()){Text("▶  Live TV")}; OutlinedButton({nav.navigate("movies")},Modifier.fillMaxWidth()){Text("🎬  Movies")}; OutlinedButton({nav.navigate("series")},Modifier.fillMaxWidth()){Text("📺  Series")}
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){OutlinedButton({nav.navigate("history")},Modifier.weight(1f)){Text("History")};OutlinedButton({nav.navigate("favorites")},Modifier.weight(1f)){Text("Favorites")}}
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){OutlinedButton({nav.navigate("epg")},Modifier.weight(1f)){Text("EPG")};OutlinedButton({nav.navigate("providers")},Modifier.weight(1f)){Text("Providers")}}
  OutlinedButton({refresh()},Modifier.fillMaxWidth()){Text("Refresh all providers (${ps.size})")}; Text("Use only IPTV services and playlists you are authorized to access.",style=MaterialTheme.typography.bodySmall)
 }
}
@Composable fun StatCard(t:String,n:Int,m:Modifier){Card(m){Column(Modifier.padding(12.dp)){Text(n.toString(),style=MaterialTheme.typography.headlineSmall);Text(t)}}}

@Composable fun LiveScreen(nav:NavHostController,ch:List<Channel>,db:JeetaDatabase){var q by remember{mutableStateOf("")};var group by remember{mutableStateOf("All")};val groups=listOf("All")+ch.filter{it.kind=="live"}.map{it.group}.distinct().sorted();val list=ch.filter{it.kind=="live"&&(group=="All"||it.group==group)&&it.name.contains(q,true)};Column(Modifier.fillMaxSize().padding(12.dp)){OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Search live channels")});Spacer(Modifier.height(8.dp));LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(groups){g->FilterChip(g==group,{group=g},{Text(g)})}};LazyColumn{items(list,key={it.id}){c->ChannelRow(c,db){openPlayer(nav,c)}}}}
}
@Composable fun CatalogScreen(nav:NavHostController,title:String,items:List<Channel>,db:JeetaDatabase){var q by remember{mutableStateOf("")};val list=items.filter{it.name.contains(q,true)};Column(Modifier.fillMaxSize().padding(12.dp)){Text(title,style=MaterialTheme.typography.headlineMedium);OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Search $title")});LazyColumn{items(list,key={it.id}){c->ChannelRow(c,db){openPlayer(nav,c)}}}}}
@Composable fun ChannelRow(c:Channel,db:JeetaDatabase,onClick:()->Unit){var fav by remember{mutableStateOf(false)};LaunchedEffect(c.id){fav=db.favorites().exists(c.id)};ListItem(headlineContent={Text(c.name)},supportingContent={Text(c.group)},leadingContent={Text(if(c.kind=="movie")"🎬" else if(c.kind=="series")"📺" else "▶")},trailingContent={TextButton({fav=!fav; kotlinx.coroutines.GlobalScope.launch{if(fav)db.favorites().add(FavoriteEntity(c.id,c.kind))else db.favorites().removeById(c.id))}}){Text(if(fav)"★" else "☆")}},modifier=Modifier.clickable{onClick()})}
fun openPlayer(nav:NavHostController,c:Channel){if(c.streamUrl.startsWith("xtream-series://"))return;nav.navigate("player/${URLEncoder.encode(c.streamUrl,"UTF-8")}/${URLEncoder.encode(c.name,"UTF-8")}")}

@Composable fun FavoritesScreen(nav:NavHostController,ch:List<Channel>,db:JeetaDatabase){var ids by remember{mutableStateOf(emptySet<String>())};LaunchedEffect(Unit){ids=db.favorites().all().map{it.contentId}.toSet()};val list=ch.filter{it.id in ids};Column(Modifier.fillMaxSize().padding(12.dp)){Text("Favorites",style=MaterialTheme.typography.headlineMedium);LazyColumn{items(list,key={it.id}){c->ChannelRow(c,db){openPlayer(nav,c)}}}}}
@Composable fun HistoryScreen(nav:NavHostController,db:JeetaDatabase){var h by remember{mutableStateOf<List<HistoryEntity>>(emptyList())};LaunchedEffect(Unit){h=db.history().recent()};Column(Modifier.fillMaxSize().padding(12.dp)){Text("Continue Watching",style=MaterialTheme.typography.headlineMedium);LazyColumn{items(h,key={it.contentId}){x->ListItem(headlineContent={Text(x.title.ifBlank{"Watched item"})},supportingContent={Text(x.type)},modifier=Modifier.clickable{nav.navigate("player/${URLEncoder.encode(x.url,"UTF-8")}/${URLEncoder.encode(x.title,"UTF-8")}")})}}}}
@Composable fun EpgScreen(){Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("EPG / TV Guide",style=MaterialTheme.typography.headlineMedium);Text("XMLTV guide support is available in the data layer. Add your XMLTV URL in the provider settings in the next provider-sync pass.");Text("Program matching uses tvg-id when supplied by your playlist.")}}
@Composable fun ProviderScreen(db:JeetaDatabase,ps:List<Provider>,refresh:()->Unit){var add by remember{mutableStateOf(false)};val scope=rememberCoroutineScope();if(add)AddPlaylistScreen(db){add=false;refresh()};if(!add)Column(Modifier.fillMaxSize().padding(16.dp)){Text("Providers",style=MaterialTheme.typography.headlineMedium);Button({add=true},Modifier.fillMaxWidth()){Text("Add provider")};Spacer(Modifier.height(8.dp));LazyColumn{items(ps,key={it.id}){p->ListItem(headlineContent={Text(p.name)},supportingContent={Text(p.type.label+" • "+p.baseUrl)},trailingContent={TextButton({scope.launch{db.providers().delete(p.id);refresh()}}){Text("Delete")}})}}}}
@Composable fun SettingsScreen(nav:NavHostController,db:JeetaDatabase){var confirm by remember{mutableStateOf(false)};val scope=rememberCoroutineScope();Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Settings",style=MaterialTheme.typography.headlineMedium);Text("Player: Media3 / ExoPlayer",style=MaterialTheme.typography.bodyLarge);Text("Fullscreen, audio/subtitle tracks and adaptive streaming are handled by the player when the stream exposes them.");Text("Parental controls, profiles, casting and advanced Android TV controls are planned as the next hardening layer.");OutlinedButton({confirm=true},Modifier.fillMaxWidth()){Text("Clear watching history")};OutlinedButton({nav.popBackStack()},Modifier.fillMaxWidth()){Text("Back")}};if(confirm)AlertDialog(onDismissRequest={confirm=false},title={Text("Clear history?")},text={Text("This removes local Continue Watching history.")},confirmButton={TextButton({scope.launch{db.history().clear();confirm=false}}){Text("Clear")}},dismissButton={TextButton({confirm=false}){Text("Cancel")}})}}
