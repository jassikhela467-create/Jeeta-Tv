package com.jeetatv.app.ui

import android.view.ViewGroup
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.jeetatv.app.data.HistoryEntity
import com.jeetatv.app.data.JeetaDatabase
import kotlinx.coroutines.launch

@Composable
fun PlayerScreen(url:String,db:JeetaDatabase,title:String="Jeeta TV"){
 val context=androidx.compose.ui.platform.LocalContext.current; val scope=rememberCoroutineScope()
 val player=remember(url){ExoPlayer.Builder(context).build()}
 DisposableEffect(player){player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.playWhenReady=true;onDispose{scope.launch{db.history().upsert(HistoryEntity(url,url,title,"live",System.currentTimeMillis(),player.currentPosition,player.duration.coerceAtLeast(0)))};player.release()}}
 AndroidView(factory={ctx->PlayerView(ctx).apply{layoutParams=ViewGroup.LayoutParams(-1,-1);this.player=player;useController=true}},modifier=Modifier)
}
