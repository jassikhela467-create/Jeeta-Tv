package com.jeetatv.app.data

object M3UParser {
    private val attributeRegex = Regex("""([\w-]+)=(?:"([^"]*)"|([^\s]*))""")

    fun parse(text: String, providerId: Long = 0): List<Channel> {
        val result = mutableListOf<Channel>()
        var attributes = emptyMap<String, String>()
        var name = ""

        text.lineSequence().forEach { rawLine ->
            val line = rawLine.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    attributes = attributeRegex.findAll(line).associate { match ->
                        match.groupValues[1] to (match.groupValues[2].ifBlank { match.groupValues[3] })
                    }
                    name = line.substringAfterLast(",", "Channel").trim()
                }
                line.isNotBlank() && !line.startsWith("#") -> {
                    val logo = attributes["tvg-logo"]?.takeIf { it.isNotBlank() }
                    val group = attributes["group-title"]?.takeIf { it.isNotBlank() } ?: "Other"
                    val tvgId = attributes["tvg-id"]?.takeIf { it.isNotBlank() }
                    result += Channel(
                        id = "${providerId}_${result.size}",
                        providerId = providerId,
                        name = name.ifBlank { "Channel ${result.size + 1}" },
                        group = group,
                        logo = logo,
                        streamUrl = line,
                        tvgId = tvgId
                    )
                    attributes = emptyMap()
                    name = ""
                }
            }
        }
        return result
    }
}
