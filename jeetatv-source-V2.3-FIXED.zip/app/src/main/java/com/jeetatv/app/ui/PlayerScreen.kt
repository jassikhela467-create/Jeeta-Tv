package com.jeetatv.app.ui

import android.view.ViewGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.jeetatv.app.data.HistoryEntity
import com.jeetatv.app.data.JeetaDatabase
import kotlinx.coroutines.launch

@Composable
fun PlayerScreen(url: String, db: JeetaDatabase, title: String = "Jeeta TV") {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var playerError by remember(url) { mutableStateOf<String?>(null) }
    var isPreparing by remember(url) { mutableStateOf(true) }

    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    playerError = error.errorCodeName + ": " + (error.message ?: "Playback failed")
                    isPreparing = false
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        isPreparing = false
                    }
                }
            })
        }
    }

    DisposableEffect(player, url) {
        try {
            val uri = android.net.Uri.parse(url)
            val builder = MediaItem.Builder().setUri(uri)
            val lower = url.lowercase()
            if (lower.contains(".m3u8") || lower.contains("m3u8?")) {
                builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            }
            player.setMediaItem(builder.build())
            player.prepare()
            player.playWhenReady = true
        } catch (t: Throwable) {
            playerError = t.message ?: "Unable to open this stream"
            isPreparing = false
        }

        onDispose {
            val position = player.currentPosition.coerceAtLeast(0L)
            val duration = if (player.duration > 0) player.duration else 0L
            scope.launch {
                runCatching {
                    db.history().upsert(
                        HistoryEntity(url, url, title, "live", System.currentTimeMillis(), position, duration)
                    )
                }
            }
            player.release()
        }
    }

    if (playerError != null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text("Unable to play this channel")
            Text(playerError ?: "Playback error", modifier = Modifier.padding(top = 8.dp))
            Text("The stream may be offline, blocked, or unsupported by the provider.", modifier = Modifier.padding(top = 8.dp))
        }
    } else {
        if (isPreparing) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator()
                Text("Connecting to $title...", modifier = Modifier.padding(top = 12.dp))
            }
        }

        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(-1, -1)
                    this.player = player
                    useController = true
                }
            },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize()
        )
    }
}
