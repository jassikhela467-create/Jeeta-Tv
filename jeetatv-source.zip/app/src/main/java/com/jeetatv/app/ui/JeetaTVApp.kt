package com.jeetatv.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.jeetatv.app.data.*
import kotlinx.coroutines.launch
import java.net.URLEncoder

@Composable fun JeetaTVApp(db: JeetaDatabase) {
    val nav=rememberNavController(); val scope=rememberCoroutineScope(); var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }; var error by remember { mutableStateOf<String?>(null) }
    fun refresh() { scope.launch { runCatching { db.providers().all().flatMap { loadProvider(it.toModel()) } }.onSuccess { channels=it }.onFailure { error=it.message ?: "Could not load providers" } } }
    LaunchedEffect(Unit) { refresh() }
    Scaffold(bottomBar={ NavigationBar { listOf("home" to "Home","live" to "Live","movies" to "Movies","series" to "Series","favorites" to "Favorites").forEach{(r,l)-> NavigationBarItem(selected=false,onClick={nav.navigate(r)},icon={},label={Text(l)}) } } }) { p ->
        NavHost(nav,"home",Modifier.padding(p)) {
            composable("home"){ HomeScreen(nav,channels.size,refresh) }
            composable("live"){ LiveScreen(nav,channels,db) }
            composable("movies"){ CatalogScreen("Movies", channels.filter{it.kind=="movie"}) }
            composable("series"){ CatalogScreen("Series", channels.filter{it.kind=="series"}) }
            composable("favorites"){ FavoritesScreen(nav,channels,db) }
            composable("add"){ AddPlaylistScreen(db){ refresh(); nav.popBackStack() } }
            composable("player/{url}"){ b -> PlayerScreen(java.net.URLDecoder.decode(b.arguments?.getString("url").orEmpty(),"UTF-8"),db) }
        }
    }
    error?.let { msg -> AlertDialog(onDismissRequest={error=null},confirmButton={TextButton({error=null}){Text("OK")}},title={Text("Jeeta TV")},text={Text(msg)}) }
}

@Composable fun HomeScreen(nav:NavHostController,count:Int,onRefresh:()->Unit){ Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){ Text("Jeeta TV",style=MaterialTheme.typography.headlineLarge); Text("Your IPTV player"); Button({nav.navigate("add")},Modifier.fillMaxWidth()){Text("Add playlist / provider")}; OutlinedButton({onRefresh()},Modifier.fillMaxWidth()){Text("Refresh channels")}; Text("$count channels loaded"); Text("Supports M3U/M3U8, Xtream Codes and compatible Portal/MAC services. Use only services you are authorized to access.",style=MaterialTheme.typography.bodyMedium) } }

@Composable fun LiveScreen(nav:NavHostController,channels:List<Channel>,db:JeetaDatabase){ var q by remember{mutableStateOf("")}; val live=channels.filter{it.kind=="live" && it.name.contains(q,true)}; Column(Modifier.fillMaxSize().padding(12.dp)){ OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("Search channels")}); Spacer(Modifier.height(8.dp)); LazyColumn{items(live){c-> ChannelRow(c){ val u=URLEncoder.encode(c.streamUrl,"UTF-8"); nav.navigate("player/$u") } } } } }

@Composable fun CatalogScreen(title:String,items:List<Channel>){ Column(Modifier.fillMaxSize().padding(20.dp)){Text(title,style=MaterialTheme.typography.headlineMedium); Text(if(items.isEmpty()) "No content loaded yet." else "${items.size} items available.")} }

@Composable fun FavoritesScreen(nav:NavHostController,channels:List<Channel>,db:JeetaDatabase){ var ids by remember{mutableStateOf(emptySet<String>())}; LaunchedEffect(Unit){ids=db.favorites().all().map{it.contentId}.toSet()}; val list=channels.filter{it.id in ids}; Column(Modifier.fillMaxSize().padding(12.dp)){Text("Favorites",style=MaterialTheme.typography.headlineMedium); LazyColumn{items(list){c->ChannelRow(c){nav.navigate("player/${URLEncoder.encode(c.streamUrl,"UTF-8")}")}}} } }

@Composable fun ChannelRow(c:Channel,onClick:()->Unit){ ListItem(headlineContent={Text(c.name)},supportingContent={Text(c.group)},leadingContent={Text("▶")},modifier=Modifier.clickable{onClick()}) }
