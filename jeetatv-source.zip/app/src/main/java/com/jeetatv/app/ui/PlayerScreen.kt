package com.jeetatv.app.ui

import android.net.Uri
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.jeetatv.app.data.HistoryEntity
import com.jeetatv.app.data.JeetaDatabase

@Composable fun PlayerScreen(url:String,db:JeetaDatabase){ val context=androidx.compose.ui.platform.LocalContext.current; val player=remember(url){ExoPlayer.Builder(context).build().apply{setMediaItem(MediaItem.fromUri(Uri.parse(url)));prepare();playWhenReady=true}}; DisposableEffect(player){onDispose{db.history().upsert(HistoryEntity(url,url,System.currentTimeMillis(),player.currentPosition));player.release()}}; AndroidView(factory={PlayerView(it).apply{this.player=player;useController=true}},modifier=Modifier.fillMaxSize()) }
