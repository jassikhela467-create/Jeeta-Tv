package com.jeetatv.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

interface ProviderAdapter { suspend fun load(provider: Provider): List<Channel> }

class M3UProviderAdapter(private val http: OkHttpClient = OkHttpClient()) : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(provider.baseUrl).header("User-Agent", "JeetaTV/1.0").build()
        http.newCall(request).execute().use { response ->
            require(response.isSuccessful) { "Playlist request failed: ${response.code}" }
            M3UParser.parse(response.body?.string().orEmpty(), provider.id)
        }
    }
}

class XtreamProviderAdapter(private val http: OkHttpClient = OkHttpClient()) : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        val base = provider.baseUrl.trimEnd('/')
        val u = provider.username ?: error("Xtream username is required")
        val p = provider.password ?: error("Xtream password is required")
        fun get(action: String): JSONArray {
            val url = "$base/player_api.php?username=${URLEncoder.encode(u, "UTF-8")}&password=${URLEncoder.encode(p, "UTF-8")}&action=$action"
            http.newCall(Request.Builder().url(url).header("User-Agent", "JeetaTV/1.0").build()).execute().use { r ->
                require(r.isSuccessful) { "Xtream request failed: ${r.code}" }
                val body = r.body?.string().orEmpty()
                return JSONArray(body)
            }
        }
        val out = mutableListOf<Channel>()
        runCatching {
            val cats = get("get_live_categories")
            val names = mutableMapOf<String,String>()
            for (i in 0 until cats.length()) { val x=cats.getJSONObject(i); names[x.optString("category_id")] = x.optString("category_name") }
            val streams = get("get_live_streams")
            for (i in 0 until streams.length()) {
                val x=streams.getJSONObject(i); val id=x.optString("stream_id")
                if (id.isNotBlank()) out += Channel("${provider.id}_live_$id", provider.id, x.optString("name","Channel"), names[x.optString("category_id")] ?: "Live", x.optString("stream_icon").ifBlank{null}, "$base/live/$u/$p/$id.m3u8", kind="live")
            }
        }.getOrThrow()
        out
    }
}

class PortalProviderAdapter(private val http: OkHttpClient = OkHttpClient()) : ProviderAdapter {
    override suspend fun load(provider: Provider): List<Channel> = withContext(Dispatchers.IO) {
        val mac = provider.macAddress?.trim().orEmpty().ifBlank { error("MAC address is required") }
        val base = provider.baseUrl.trimEnd('/')
        val deviceId = md5(mac)
        val headers = Headers.Builder().add("User-Agent", "Mozilla/5.0").add("X-User-Agent", "Model: MAG254; Link: WiFi").add("Cookie", "mac=$mac; stb_lang=en; timezone=GMT").build()
        fun request(url: String): JSONObject {
            http.newCall(Request.Builder().url(url).headers(headers).build()).execute().use { r ->
                require(r.isSuccessful) { "Portal request failed: ${r.code}" }
                return JSONObject(r.body?.string().orEmpty())
            }
        }
        val handshake = request("$base/portal.php?type=stb&action=handshake&token=&prehash=0&JsHttpRequest=1-xml")
        val token = handshake.optJSONObject("js")?.optString("token").orEmpty()
        require(token.isNotBlank()) { "Portal handshake failed" }
        val authHeaders = headers.newBuilder().add("Authorization", "Bearer $token").build()
        fun get(url: String): JSONObject = http.newCall(Request.Builder().url(url).headers(authHeaders).build()).execute().use { r -> JSONObject(r.body?.string().orEmpty()) }
        get("$base/portal.php?type=stb&action=get_profile&hd=1&ver=ImageDescription:1.0.0&device_id=$deviceId&device_id2=$deviceId&sn=$deviceId&JsHttpRequest=1-xml")
        val list = get("$base/portal.php?type=itv&action=get_all_channels&JsHttpRequest=1-xml")
        val arr = list.optJSONObject("js")?.optJSONArray("data") ?: JSONArray()
        val out=mutableListOf<Channel>()
        for(i in 0 until arr.length()) { val x=arr.getJSONObject(i); val id=x.optString("id"); val name=x.optString("name"); if(id.isNotBlank() && name.isNotBlank()) out += Channel("${provider.id}_portal_$id", provider.id, name, x.optString("cmd","Other"), x.optString("logo").ifBlank{null}, "$base/portal.php?type=itv&action=create_link&cmd=${URLEncoder.encode(x.optString("cmd"),"UTF-8")}&JsHttpRequest=1-xml", kind="live") }
        out
    }
    private fun md5(s:String):String { val b=java.security.MessageDigest.getInstance("MD5").digest(s.toByteArray()); return b.joinToString("") { "%02x".format(it) } }
}

suspend fun loadProvider(provider: Provider): List<Channel> = when(provider.type) {
    ProviderType.M3U -> M3UProviderAdapter().load(provider)
    ProviderType.XTREAM -> XtreamProviderAdapter().load(provider)
    ProviderType.PORTAL -> PortalProviderAdapter().load(provider)
}
