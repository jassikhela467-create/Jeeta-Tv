package com.jeetatv.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.jeetatv.app.data.*
import kotlinx.coroutines.launch

@Composable fun AddPlaylistScreen(db:JeetaDatabase,onSaved:()->Unit){ var type by remember{mutableStateOf(ProviderType.M3U)}; var name by remember{mutableStateOf("")}; var url by remember{mutableStateOf("")}; var user by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}; var mac by remember{mutableStateOf("")}; var busy by remember{mutableStateOf(false)}; var error by remember{mutableStateOf<String?>(null)}; val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){ Text("Add Provider",style=MaterialTheme.typography.headlineMedium); Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){ProviderType.values().forEach{FilterChip(type==it,{type=it},{Text(it.label)})}}; OutlinedTextField(name,{name=it},label={Text("Name")},modifier=Modifier.fillMaxWidth()); OutlinedTextField(url,{url=it},label={Text(if(type==ProviderType.M3U) "M3U/M3U8 URL" else "Server / Portal URL")},modifier=Modifier.fillMaxWidth()); if(type==ProviderType.XTREAM){OutlinedTextField(user,{user=it},label={Text("Username")},modifier=Modifier.fillMaxWidth()); OutlinedTextField(pass,{pass=it},label={Text("Password")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())}; if(type==ProviderType.PORTAL){OutlinedTextField(mac,{mac=it},label={Text("MAC address")},modifier=Modifier.fillMaxWidth()); Text("Portal implementations vary. Enter the portal URL supplied by your authorized provider.")}; Button(enabled=!busy,onClick={scope.launch{busy=true;runCatching{require(name.isNotBlank()){ "Name is required" };require(url.isNotBlank()){ "URL is required" };if(type==ProviderType.XTREAM){require(user.isNotBlank()&&pass.isNotBlank()){ "Username and password are required" }};if(type==ProviderType.PORTAL)require(mac.isNotBlank()){ "MAC address is required" };db.providers().insert(Provider(name=name,type=type,baseUrl=url.trim(),username=user.ifBlank{null},password=pass.ifBlank{null},macAddress=mac.ifBlank{null}).toEntity())}.onSuccess{onSaved()}.onFailure{error=it.message}.also{busy=false}}},Modifier.fillMaxWidth()){Text(if(busy)"Saving…" else "Save Provider")}; error?.let{Text(it,color=MaterialTheme.colorScheme.error)} }
}
