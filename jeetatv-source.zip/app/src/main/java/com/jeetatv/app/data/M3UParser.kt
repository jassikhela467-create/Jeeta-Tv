package com.jeetatv.app.data

object M3UParser {
    private val attr = Regex("""([\\w-]+)=(?:\"([^\"]*)\"|([^\\s]*))""")
    fun parse(text:String,providerId:Long=0):List<Channel>{
        val out=mutableListOf<Channel>(); var attrs=emptyMap<String,String>(); var name=""
        text.lineSequence().map{it.trim()}.forEach{line->
            when{
                line.startsWith("#EXTINF",true)->{attrs=attr.findAll(line).associate{it.groupValues[1] to (it.groupValues[2].ifBlank{it.groupValues[3]})}; name=line.substringAfterLast(",","Channel").trim()}
                line.isNotBlank()&&!line.startsWith("#")-> { out += Channel("${providerId}_${out.size}",providerId,name.ifBlank{"Channel ${out.size+1}"},attrs["group-title"]?:"Other",attrs["tvg-logo"].ifBlank{null},line,attrs["tvg-id"]); attrs=emptyMap();name="" }
            }
        }; return out
    }
}
