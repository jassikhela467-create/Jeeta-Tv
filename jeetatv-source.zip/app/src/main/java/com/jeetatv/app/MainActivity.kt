package com.jeetatv.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.room.Room
import com.jeetatv.app.data.JeetaDatabase
import com.jeetatv.app.ui.JeetaTVApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, JeetaDatabase::class.java, "jeetatv.db").fallbackToDestructiveMigration().build()
        setContent { JeetaTVApp(db) }
    }
}
