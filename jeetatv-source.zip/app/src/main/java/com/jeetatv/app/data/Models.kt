package com.jeetatv.app.data

enum class ProviderType(val label: String) { M3U("M3U / M3U8"), XTREAM("Xtream Codes"), PORTAL("Portal / MAC") }

data class Provider(
    val id: Long = 0,
    val name: String,
    val type: ProviderType,
    val baseUrl: String,
    val username: String? = null,
    val password: String? = null,
    val macAddress: String? = null,
    val autoRefresh: Boolean = true
)

data class Channel(
    val id: String,
    val providerId: Long,
    val name: String,
    val group: String = "Other",
    val logo: String? = null,
    val streamUrl: String,
    val tvgId: String? = null,
    val favorite: Boolean = false,
    val kind: String = "live"
)

data class EpgProgram(val channelId: String, val title: String, val description: String = "", val startMs: Long, val endMs: Long)

data class XtreamItem(val id: String, val name: String, val streamUrl: String, val logo: String? = null, val group: String = "Other", val kind: String = "movie")
